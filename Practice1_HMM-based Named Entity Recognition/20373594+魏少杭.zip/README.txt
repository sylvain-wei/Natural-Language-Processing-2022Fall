代码：HMM.py
数据集：train.json、env.json
结果：output版本1.txt、output版本2.txt